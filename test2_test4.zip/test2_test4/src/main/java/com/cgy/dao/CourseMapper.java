package com.cgy.dao;

import com.cgy.pojo.Course;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseMapper {
    public Integer addCourse(Course course);
    public Integer deleteCourseById(@Param(value = "id") Integer id);
    public Course queryCourseById(@Param(value = "id")int id);
    public Integer updateCourse(Course course);
    public List<Course> queryAllCourse(@Param(value = "curPage") int curPage, @Param(value = "pageSize") int pageSize);
    public int queryCourseCount();
    public List<Course> queryCourseByName(@Param(value = "courseName")String courseName,@Param(value = "curPage")int curPage,@Param(value = "pageSize")int pageSize);
    public int queryCourseCountByName(@Param(value = "courseName")String courseName);
    public int insertSelective(Course course);




}
