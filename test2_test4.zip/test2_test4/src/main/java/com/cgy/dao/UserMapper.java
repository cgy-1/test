package com.cgy.dao;

import com.cgy.pojo.User;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface UserMapper {
    @Select("select * from user where user_email=#{email} AND user_password=#{password} ")
    @Results(id = "userMap",value = {
            //id字段默认为false，表示不是主键
            //column表示数据库表字段，property表示实体类属性名。
            @Result(id = true,column = "user_id",property = "id"),

            @Result(column = "user_password",property = "password"),
            @Result(column = "user_email",property = "email"),


    })
    User login(User user);
}
