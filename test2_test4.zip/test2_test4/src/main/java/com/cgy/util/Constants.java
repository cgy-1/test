package com.cgy.util;

public class Constants {
    public static final String IMG_PATH = "D:/tools/apache-tomcat-9.0.73/FileDir/photos/";
}
