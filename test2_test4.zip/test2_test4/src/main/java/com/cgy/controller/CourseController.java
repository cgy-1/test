package com.cgy.controller;

import com.cgy.dto.PaginationDTO;
import com.cgy.pojo.Course;
import com.cgy.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@ComponentScan("com.cgy.service")
@RequestMapping("/course")
public class CourseController {
    @Autowired
    private CourseService courseService;


    @RequestMapping("/allCourse")
    public String list(Model model,
                       @RequestParam(name="curPage",defaultValue = "1") Integer curPage,
                       @RequestParam(name = "pageSize",defaultValue = "5")Integer pageSize){
        PaginationDTO paginationDTO = courseService.queryAllCourse(curPage,pageSize);
        model.addAttribute("list",paginationDTO);
        return "allCourse";

    }




    @RequestMapping("/toUpdateCourse")
    public String toUpdateBook(Model model, int id) {
        Course course = courseService.queryCourseById(id);
        System.out.println(course);
        model.addAttribute("course",course );
        return "updateCourse";
    }

    @RequestMapping("/updateCourse")
    public String updateBook(Model model, Course course) {
        System.out.println(course);
        courseService.updateCourse(course);
        Course course1 = courseService.queryCourseById(course.getId());
        model.addAttribute("course", course1);
        return "redirect:/course/allCourse";
    }

    @RequestMapping("/del/{id}")
    public String deleteCourse(@PathVariable("id") int id) {
        courseService.deleteCourseById(id);
        return "redirect:/course/allCourse";
    }

    @RequestMapping("/queryCourse")
    public String queryCourseByName(@RequestParam(name = "courseName",required = false)String courseName,
                                  @RequestParam(name="curPage",defaultValue = "1") Integer curPage,
                                  @RequestParam(name = "pageSize",defaultValue = "5")Integer pageSize,
                                  Model model){
        int count = courseService.queryCourseCountByName(courseName);
        if (count == 0){
            model.addAttribute("error","未查到相关书籍");
            model.addAttribute("list",null);
            return "allCourse";
        }
        PaginationDTO paginationDTO = courseService.queryCourseByName(courseName, curPage, pageSize);
        model.addAttribute("courseName",courseName);
        model.addAttribute("list",paginationDTO);
        return "allCourse";
    }


    /**
     * 跳转到注册页面

     */
   /* @RequestMapping(value="/addCourse")
    public String addPaper(Course course) {
        System.out.println(course);
        courseService.addCourse(course);
        return "redirect:/course/allCourse";
    }*/

    @RequestMapping("/toAddCourse")
    public String toAddPaper() {
        return "addCourse";
    }
    /**
     * 跳转到注册页面
     * @param model
     * @return
     */
    @RequestMapping(value="/addCourse",method = RequestMethod.GET)
    public String register(Model model){
        /*
         为什么这里要 new 一个 User 对象？
         因为我们在 JSP 页面中使用了 spring form 标签
         spring form 标签的 modelAttribute 默认需要一个对象用于接收数据
         这里我们是新增，所以用无参构造创建一个空对象（不是null）
          */
        Course course = new Course();
        model.addAttribute("course", course); // user 加入到 request 域
        return "addCourse"; // 跳转到 user/register.jsp 页面
    }


    /**
     * 处理用户注册的表单请求
     * @param course
     * @param file
     * @return
     */
    @RequestMapping(value = "/addCourse", method = RequestMethod.POST)
    public String doR(Course course,
                             @RequestParam("imgFile") MultipartFile file,
                             Model model){
        if (courseService.saveRegister(course, file)){
            model.addAttribute("course", course);
           /* return "redirect:/course/allCourse";*/
            // 注册成功，跳转到显示页面
            return "redirect:/course/allCourse";
        }
        return "redirect:/course/addCourse"; // 注册失败，重定向到注册页面
    }

}
