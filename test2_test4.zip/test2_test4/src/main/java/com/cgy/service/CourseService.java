package com.cgy.service;

import com.cgy.dto.PaginationDTO;
import com.cgy.pojo.Course;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

public interface CourseService {
    public Integer addCourse(Course course);
    public Integer deleteCourseById(Integer id);
    public Integer updateCourse(Course course);
    public Course queryCourseById(int id);

   public  PaginationDTO queryAllCourse(Integer curPage, Integer pageSize);


    public int queryCourseCountByName(@Param(value = "courseName")String courseName);

    public PaginationDTO queryCourseByName(String courseName,Integer curPage, Integer pageSize);
    public boolean saveRegister(Course course, MultipartFile file);
}
